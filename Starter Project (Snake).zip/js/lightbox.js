const imagenes = document.querySelectorAll('.img-galeria')
const imagenesLight = document.querySelector('.agregar-imagen')
const contenedorLight = document.querySelector('.imagen-light')

imagenes.forEach(imagen =>{
  imagen.addEventListener('click', ()=>{
    
  })
  
})

const aparecerImagen = (imagen)=>{
  
  
}
